<h1>Sessió Caducada</h1>
<?php
session_start();
session_destroy();
?>
<button> <a href="index.php"> Log in</a> </button>