<div class="topnav-right">
      <a href="Funcionalitats/logout.php" style="width:auto;">Log-out</a>
</div>