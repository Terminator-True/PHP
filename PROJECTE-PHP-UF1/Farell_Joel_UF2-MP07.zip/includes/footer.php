<style>
    #Footer {
        background-color:PaleTurquoise;
        color:black;
        width: 100%;
        margin-top: 100%;        
        box-shadow:1px 1px 5px black;
        }
</style>
<div id="Footer" align="center">
    <table>
      
        <tr>
            <td colspan="4"> <div style="padding:20px; padding-bottom:30px"></div> </td>

        </tr>
        <tr>
            <td colspan="4"> <hr width="100%"> </div> </td>

        </tr>
        
        <tr style="color:white">
            <td colspan="4" align="center">© 2022   | Tots els drets reservats</td>
        </tr>

        <tr style="color:white">
            <td colspan="4" align="center">
                El nostre correu electrónic : info@correo.com
            </td>
        </tr>

    </table>
    
    <div style="padding:0px; padding-bottom:30px"></div>  

</div>