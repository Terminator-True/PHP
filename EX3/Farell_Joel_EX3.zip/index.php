
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Imprimir per pantalla</title>
</head>

<?php 
echo "<h1>EX2</h1>";
require "ex2.php";
echo "<h1>EX3</h1>";
require "ex3.php";
echo "<h1>EX4</h1>";
require "ex4.php";
echo "<h1>EX5</h1>";
require "ex5.php";
echo "<h1>EX6</h1>";
require "ex6.php";
echo "<h1>EX7</h1>";
require "ex7.php";
echo "<h1>EX8</h1>";
require "ex8.php";
?>
<body>

</body>

<div id="Footer" style="background-color:turquoise;color:white;width: 100%;" align="center">
<table>
  
    <tr>
        <td colspan="4"> <div style="padding:20px; padding-bottom:30px"></div> </td>

    </tr>
    <tr>
        <td colspan="4"> <hr width="100%"> </div> </td>

    </tr>
    
    <tr style="color:white">
        <td colspan="4" align="center">© 2020 EX3 | Todos los derechos reservados</td>
    </tr>

    <tr style="color:white">
        <td colspan="4" align="center">
            Nuestro correo electrónico : info@correo.com
        </td>
    </tr>

</table>

<div style="padding:0px; padding-bottom:30px"></div>  

</div>