<h1>EXAMEN UF1 PHP</h1>

<ul>
    <li>
        <a href="ex1.php">ex1.php</a>
    </li>
    <li>
        <a href="logout.php">logout.php</a>
    </li>
</ul>