<div id="Footer" style="background-color:turquoise;color:white;width: 100%;" align="center">
<table>
  
    <tr>
        <td colspan="4"> <div style="padding:20px; padding-bottom:30px"></div> </td>

    </tr>
    <tr>
        <td colspan="4"> <hr width="100%"> </div> </td>

    </tr>
    
    <tr style="color:white">
        <td colspan="4" align="center">© 2020 EXAMEN-PHP-1 | Todos los derechos reservados</td>
    </tr>

</table>

<div style="padding:0px; padding-bottom:30px"></div>  

</div>