<?php
    $unaVar = "Una variable";
?>

<div class="capçalera">
    <h1>EX5-PHP</h1>
    <hr/>
    <ul>
        <li><a href="index.php">Inici</a></li>
        <li><a href="ex1.php">ex1</a></li>
        <li><a href="ex2.php">ex2</a></li>
        <li><a href="ex3.php">ex3</a></li>
        <li><a href="ex4.php">ex4</a></li>
    </ul>
</div>