<style>
    a{
        text-decoration: none;
        color:black;
    }
</style>

<h1>Welcome<br> <?php print_r($_SESSION['usuari'])?> </h1>
<button> <img src="images/user.png" alt=""> <a href="#">Perfil</a> </button>
<button> <img src="images/entrades.png" alt=""> <a href="#">Entrades</a>  </button>
<button> <img src="images/lista.png" alt=""> <a href="#">Categoríes</a> </button>