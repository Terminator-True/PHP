<style>
    .header{
        background-color:Beige;
    }
    .header img {
        width: 5%;
        margin:auto;
        position: relative;
        margin-top:10px;
        padding:10px;
        margin-left:45%;
        
    }
</style>

<div class="header">
<a href="#home" class="active"><img src="images\ico2.svg" alt=""></a> 
</div>