<div class="topnav-right">
      <a href="#" onclick="document.getElementById('Login').style.display='block'" style="width:auto;">Login</a>
      <a href="#" onclick="document.getElementById('Sign').style.display='block'" style="width:auto;">Sign Up</a>
</div>