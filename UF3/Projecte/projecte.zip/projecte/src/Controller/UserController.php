<?php
namespace App\Controller;
//Basic import
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\RedirectResponse;
//
use App\Entity\User;
use Doctrine\Persistence\ManagerRegistry;

//Imports dels formularis
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\FormType;

//Password encription
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

//Sessió
use Symfony\Component\HttpFoundation\Session\Session;

//Login
use Symfony\Component\Security\Http\Authentication\AuthenticationUtils;

class UserController extends AbstractController{   
    /**
     * @Route("/register")
     */
    public function index(Request $request, UserPasswordHasherInterface $encoder):Response{
        $user = new User();
        //Creació del formulari
        $form=$this -> createFormBuilder($user)
                    ->setMethod("POST")
                        ->add("name",TextType::class,[
                            'label'=> "Nom",
                            'attr' =>  [ 'class' => 'form-control form-control-lg']
                        ])
                        ->add("surname",TextType::class,[
                            'label'=> "Cognom",
                            'attr' =>  [ 'class' => 'form-control form-control-lg']
                        ])
                        ->add("email",TextType::class,['label'=> "Email",'attr' =>  [ 'class' => 'form-control form-control-lg']])
                        ->add("password",TextType::class,['label'=> "Password",'attr' =>  [ 'class' => 'form-control form-control-lg' ]])
                        ->add("submit",SubmitType::class,[
                            'label'=> "Registra't",
                            'attr' =>  [ 'class' => 'btn btn-outline-light btn-lg px-5 m-5' ]
                        ]) 
                    ->getForm();
        //Agafem el contingut del formulari
        $form -> handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){
            //var_dump($user);
            //Guardem a la base de dades
            $em =  $this -> getDoctrine()->getManager();
            //Agfegim el rol de l'usuari i la data de creació
            $user->setRole('ROLE_USER');
            $user->setCreatedAt(new \Datetime('now'));
            //Codifiquem el password
            $user->setPassword($encoder->hashPassword($user, $user->getPassword()));
            //Guardem a la base de dades
            $em->persist($user);
            $em->flush();
            //Obrim una sessió per a donar el missatge de la correcta creació de l'usuari
            $session = new Session();
            $session->getFlashBag()->add("message","Usuari creat correctament");
            //Vuidem el formulari
            return $this->redirectToRoute('register');
        }

        return $this->render("User_controll/register.html.twig",[
            "form" => $form->createView()
        ]);
    }
    public function login(AuthenticationUtils $autentificationUtils){
        $error = $autentificationUtils->getLastAuthenticationError();
        $lastUsername = $autentificationUtils->getLastUsername();

        return $this -> render('User_controll/login.html.twig', [
            'error' => $error,
            'lastUsername' => $lastUsername
        ]);
    }
}