<?php
namespace App\Controller;
//Basic import
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Routing\Annotation\Route;
use Symfony\Component\HttpFoundation\RedirectResponse;

use App\Entity\Task;

use Doctrine\Persistence\ManagerRegistry;


use Symfony\Component\Security\Core\User\UserInterface;

//Sessió
use Symfony\Component\HttpFoundation\Session\Session;

//Imports dels formularis
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\FormType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\ChoiceType;

class TaskController extends AbstractController{   

    public function index(ManagerRegistry $doctrine): Response
    {
        $view=[];
        $entityManager = $doctrine->getRepository(Task::class);
        $tasks = $entityManager->findAll();
        foreach ($tasks as $task) {
            $view[]=$task; 
        } 
/*        $anterior="";
        foreach ($tasks as $task) {
            if($task->getUser()->getEmail()==$anterior){
                $view[]= "-------->".$task->getTitle();
            }else{
                $view[]= $task->getUser()->getEmail();  
                $view[]= "-------->".$task->getTitle();
                $anterior=$task->getUser()->getEmail();
            }

        }*/
        return $this->render("task_controll/tasks.html.twig",["view"=>$view]);
    }
    public function detail(Task $task){
        if (!$task) {
            return $this -> redirectToRoute('tasks');
        }else{
            return $this->render('task_controll/detail.html.twig',[
                'task'=>$task
            ]);
        }
    }
    /**
     * @Route("/task/create_task")
     * 
     */
    public function crear(Request $request, UserInterface $user): Response{
        $task = new Task();
        $form=$this -> createFormBuilder($task)
        ->setMethod("POST")
            ->add("title",TextType::class,[
                'label'=> "Títol",
                'attr' =>  [ 'class' => 'form-control form-control-lg']
            ])
            ->add("content",TextareaType::class,[
                'label'=> "Contingut",
                'attr' =>  [ 'class' => 'form-control form-control-lg']
            ])
            ->add("priority",ChoiceType::class,['choices' => ['Alta'=>'Alta','Mitjana'=>'Mitjana','Baixa'=>'Baixa'],'label'=> "Prioridad",'attr' =>  [ 'class' => 'form-control form-control-lg']])
            ->add("hours",IntegerType::class,['label'=> "Hore",'attr' =>  [ 'class' => 'form-control form-control-lg' ]])
            ->add("submit",SubmitType::class,[
                'label'=> "Crear Tasca",
                'attr' =>  [ 'class' => 'btn btn-outline-light btn-lg px-5 m-5' ]
            ]) 
        ->getForm();
        
        $form->handleRequest($request);
        if($form->isSubmitted() && $form->isValid()){

            $task->setCreatedAt(new \DateTime('now'));
            $task->setUser($user);
            //Obrim una sessió per a donar el missatge de la correcta creació de la tasca
            $session = new Session();
            $session->getFlashBag()->add("message","Tasca creada correctament");
            $em = $this->getDoctrine()->getManager();
            $em->persist($task);
            $em->flush();
        }
        return $this->render('task_controll/crear.html.twig',[
                'form'=>$form->createView()
        ]);
    }
    /**
     * @Route("/task/My_tasks")
     * 
     */
    public function MyTasks(ManagerRegistry $doctrine, UserInterface $user): Response{
        $view=[];
        $entityManager = $doctrine->getRepository(Task::class);
        $tasks = $entityManager->findAll();
        foreach ($tasks as $task) {
            if ($user->getEmail()==$task->getUser()->getEmail()) {
                $view[]=$task;     
            }
        } 
        return $this->render("task_controll/my-tasks.html.twig",["view"=>$view]);
    }
     /**
     * @Route("/edit_tasks")
     * 
     */
    public function edit(Request $request, UserInterface $user, Task $task): Response{
        if (!$user || $user->getEmail()!=$task->getUser()->getEmail()) {
            return $this -> redirectToRoute('tasks');
        }else{
            $form=$this -> createFormBuilder($task)
            ->setMethod("POST")
                ->add("title",TextType::class,[
                    'label'=> "Títol",
                    'attr' =>  [ 'class' => 'form-control form-control-lg']
                ])
                ->add("content",TextareaType::class,[
                    'label'=> "Contingut",
                    'attr' =>  [ 'class' => 'form-control form-control-lg']
                ])
                ->add("priority",ChoiceType::class,['choices' => ['Alta'=>'Alta','Mitjana'=>'Mitjana','Baixa'=>'Baixa'],'label'=> "Prioridad",'attr' =>  [ 'class' => 'form-control form-control-lg']])
                ->add("hours",IntegerType::class,['label'=> "Hore",'attr' =>  [ 'class' => 'form-control form-control-lg' ]])
                ->add("submit",SubmitType::class,[
                    'label'=> "Crear Tasca",
                    'attr' =>  [ 'class' => 'btn btn-outline-light btn-lg px-5 m-5' ]
                ]) 
            ->getForm();
            
            $form->handleRequest($request);
            if($form->isSubmitted() && $form->isValid()){
    
                $task->setCreatedAt(new \DateTime('now'));
                $task->setUser($user);
                //Obrim una sessió per a donar el missatge de la correcta creació de la tasca
                $session = new Session();
                $session->getFlashBag()->add("message","Tasca modificada correctament");
                $em = $this->getDoctrine()->getManager();
                $em->persist($task);
                $em->flush();
            }
            return $this->render('task_controll/crear.html.twig',[
                    'edit'=>true,
                    'form'=>$form->createView()
            ]);
        }

        
    }
    /**
     * @Route("/remove/{id}")
     * 
     */
    public function remove(ManagerRegistry $doctrine,Task $task){
        if (!$task) {
            return $this -> redirectToRoute('tasks');
        }else{
            $em = $this->getDoctrine()->getManager();
            $em->remove($task);
            $em->flush();
            return $this -> redirectToRoute('tasks');
        }

    }
}